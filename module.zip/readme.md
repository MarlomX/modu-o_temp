![Downloads](https://img.shields.io/github/downloads/Larkinabout/fvtt-token-action-hud-core/latest/module.zip?color=2b82fc&label=DOWNLOADS&style=for-the-badge) [![Forge Installs](https://img.shields.io/badge/dynamic/json?label=Forge%20Installs&query=package.installs&suffix=%25&url=https%3A%2F%2Fforge-vtt.com%2Fapi%2Fbazaar%2Fpackage%2Ftoken-action-hud-core&colorB=448d34&style=for-the-badge)](https://forge-vtt.com/bazaar#package=token-action-hud-core)

# Token Action HUD Core

Token Action HUD is a repositionable HUD of actions for a selected token.

![Token Action HUD](.github/readme/token-action-hud.gif)

# Features
- Make rolls directly from the HUD instead of opening your character sheet.
- Use items from the HUD or right-click an item to open its sheet.
- Move the HUD and choose to expand the menus up or down.
- Unlock the HUD to customise the groups and actions.
- Add your own macros and Journal Entry and Roll Table compendiums.

# Installation

## Method 1
1. In Foundry VTT's **Configuration and Setup** screen, click **Add-on Modules**
2. Click **Install Module**
3. Search for **Token Action HUD Core**
4. Click **Install** next to the module listing

## Method 2
1. In Foundry VTT's **Configuration and Setup** screen, click **Add-on Modules**
2. Click **Install Module**
3. In the Manifest URL field, paste: `https://github.com/Larkinabout/fvtt-token-action-hud-core/releases/latest/download/module.json`
4. Click **Install** next to the pasted Manifest URL

# Required Modules

## Token Action HUD System Modules
Token Action HUD Core requires a companion Token Action HUD system module to be installed. Current system modules are:

- [Token Action HUD 13th Age](https://foundryvtt.com/packages/token-action-hud-13th-age)
- [Token Action HUD for Alien RPG](https://foundryvtt.com/packages/token-action-hud-alien)
- [Token Action HUD for Anime Campaign](https://foundryvtt.com/packages/token-action-hud-ac)
- [Token Action HUD BCDice](https://foundryvtt.com/packages/token-action-hud-bcdice)
- [Token Action HUD Black Flag](https://foundryvtt.com/packages/token-action-hud-bf)
- [Token Action HUD for Blade Runner](https://foundryvtt.com/packages/token-action-hud-bladerunner)
- [Token Action HUD Cairn](https://foundryvtt.com/packages/token-action-hud-cairn)
- [Token Action HUD Castles & Crusades](https://foundryvtt.com/packages/fvtt-token-action-hud-castles-and-crusades)
- [Token Action HUD CoC7](https://foundryvtt.com/packages/token-action-coc-7)
- [Token Action HUD COF1e](https://foundryvtt.com/packages/fvtt-token-action-hud-cof1e)
- [Token Action HUD for Coriolis](https://foundryvtt.com/packages/token-action-hud-coriolis)
- [Token Action HUD Crucible](https://foundryvtt.com/packages/token-action-hud-crucible)
- [Token Action HUD CypherSystem](https://foundryvtt.com/packages/token-action-hud-cyphersystem)
- [Token Action HUD Cyberpunk RED](https://foundryvtt.com/packages/token-action-hud-cyberpunk-red)
- [Token Action HUD DC20 RPG](https://foundryvtt.com/packages/token-action-hud-dc20rpg)
- [Token Action HUD Delta Green](https://foundryvtt.com/packages/token-action-hud-dg)
- [Token Action HUD D&D 5e](https://foundryvtt.com/packages/token-action-hud-dnd5e)
- [Token Action HUD Dragonbane](https://foundryvtt.com/packages/token-action-hud-dragonbane)
- [Token Action HUD for Dungeon Crawl Classics](https://foundryvtt.com/packages/token-action-hud-dcc)
- [Token Action HUD DS4](https://foundryvtt.com/packages/token-action-hud-ds4)
- [Token Action HUD Earthdawn](https://foundryvtt.com/packages/token-action-hud-ed4e)
- [Token Action HUD Exalted Third Edition](https://foundryvtt.com/packages/token-action-hud-exaltedthird)
- [Token Action HUD for FFG Star Wars](https://foundryvtt.com/packages/token-action-hud-ffgsw)
- [Token Action HUD for Forbidden Lands](https://foundryvtt.com/packages/token-action-hud-forbidden-lands)
- [Token Action HUD Ghostbusters](https://foundryvtt.com/packages/token-action-hud-gb)
- [Token Action HUD GURPS](https://foundryvtt.com/packages/token-action-hud-gurps)
- [Token Action HUD Ironsworn](https://foundryvtt.com/packages/token-action-hud-ironsworn)
- [Token Action HUD L5R 5e](https://foundryvtt.com/packages/token-action-hud-l5r5e)
- [Token Action HUD LANCER](https://foundryvtt.com/packages/token-action-hud-lancer)
- [Token Action HUD Mutants and Masterminds 3E](https://foundryvtt.com/packages/token-action-hud-mm3)
- [Token Action HUD for Old-School Essentials](https://foundryvtt.com/packages/token-action-hud-ose)
- [Token Action HUD OpenD6 Space](https://foundryvtt.com/packages/token-action-hud-od6s)
- [Token Action HUD Ordem Paranormal](https://foundryvtt.com/packages/token-action-hud-ordem-paranormal)
- [Token Action HUD Pathfinder 1e](https://foundryvtt.com/packages/token-action-hud-pf1)
- [Token Action HUD Pathfinder 2](https://foundryvtt.com/packages/token-action-hud-pf2e)
- [Token Action HUD Pirate Borg](https://foundryvtt.com/packages/token-action-hud-pirateborg)
- [Token Action HUD for Savage Worlds](https://foundryvtt.com/packages/token-action-hud-swade)
- [Token Action HUD Shadowdark](https://foundryvtt.com/packages/token-action-hud-shadowdark)
- [Token Action HUD Sword World 2.5](https://foundryvtt.com/packages/token-action-hud-sw25)
- [Token Action Hud Tormenta 20](https://foundryvtt.com/packages/token-action-hud-t20)
- [Token Action HUD for Symbaroum RPG](https://foundryvtt.com/packages/token-action-hud-symbaroum)
- [Token Action HUD Synthetic Dream Machine](https://foundryvtt.com/packages/token-action-hud-sdm)
- [Token Action HUD The One Ring 2e](https://foundryvtt.com/packages/token-action-hud-tor2e)
- [Token Action HUD The Witcher TRPG](https://foundryvtt.com/packages/token-action-hud-thewitchertrpg)
- [Token Action HUD for Twodsix](https://foundryvtt.com/packages/fvtt-token-action-hud-twodsix)
- [Token Action HUD WFRP4e](https://foundryvtt.com/packages/token-action-hud-wfrp4e)
- [Token Action HUD for WoD](https://foundryvtt.com/packages/token-action-hud-wod)
- [Token Action HUD Worlds Without Number](https://foundryvtt.com/packages/token-action-hud-wwn)
- [Token Action HUD Wrath & Glory](https://foundryvtt.com/packages/token-action-hud-wng)

## socketlib
Token Action HUD Core requires the [socketlib](https://foundryvtt.com/packages/socketlib) library module.

# Recommended Modules
Token Action HUD uses the [Color Picker](https://foundryvtt.com/packages/color-picker) library module for its color picker settings.

# Support

For a guide on using Token Action HUD, go to: [How to Use Token Action HUD](https://github.com/Larkinabout/fvtt-token-action-hud-core/wiki/How-to-Use-Token-Action-HUD)

For questions, feature requests or bug reports, please open an issue [here](https://github.com/Larkinabout/fvtt-token-action-hud-core/issues).

Pull requests are welcome. Please include a reason for the request or create an issue before starting one.

# Acknowledgements

Thank you to the Community Helpers on Foundry's Discord who provide tireless support for people seeking help with the HUD.

# License

This Foundry VTT module is licensed under a [Creative Commons Attribution 4.0 International License](https://creativecommons.org/licenses/by/4.0/) and this work is licensed under [Foundry Virtual Tabletop EULA - Limited License Agreement for module development](https://foundryvtt.com/article/license/).
